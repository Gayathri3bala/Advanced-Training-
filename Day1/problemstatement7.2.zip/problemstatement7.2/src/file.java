
import java.io.FileReader;
import java.io.Serializable;

public class file implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	{
		try {
			FileReader fr = new FileReader("E:\\write\\output.txt");
			String str = "";
			int i;
			while ((i = fr.read()) != -1)
				str += (char) i;
			System.out.println("Data Stored in file : \n" + str);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
