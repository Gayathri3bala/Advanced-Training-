package com.program;

import java.util.Scanner;

public class sumof2 {
	public static void main(String[] args) {
		System.out.println("Enter two numbers");
		Scanner sc = new Scanner(System.in);
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		sc.close();

		int i = 0, n = 14;
		int a = num1, b = num2;
		System.out.println("The next 13 numbers are as follows:\n");

		for (i = 0; i < n; i++) {
			System.out.print(a + " ");
			int c = a + b;
			a = b;
			b = c;
		}
	}
}
