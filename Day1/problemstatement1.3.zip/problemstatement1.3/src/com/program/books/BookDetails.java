package com.program.books;

public class BookDetails {
	private String book_title;
	private float book_price;

	public BookDetails(String Title, float Price) {
		this.book_title = Title;
		this.book_price = Price;
	}

	public String getBook_title() {
		return book_title;
	}

	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}

	public float getBook_price() {
		return book_price;
	}

	public void setBook_price(float book_price) {
		this.book_price = book_price;
	}

	public String toString() {
		return book_title + "       " + book_price;
	}

	public static void main(String args[]) {
		BookDetails b1 = new BookDetails("Java Programming", 350.50f);
		BookDetails b2 = new BookDetails("Let us C", 200);
		System.out.println("---------Book Details--------");
		System.out.println("Book Title" + "      " + "Book Price");
		System.out.println("" + b1);
		System.out.println("" + b2);
	}
}
