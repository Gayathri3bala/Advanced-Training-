
public class SLL {
	public static void main(String[] args) {
		LinkedList<Employee> linkedList = new LinkedList<Employee>(); 

		linkedList.insertFirst(new Employee("11", "Gayathri", "a1"));
		linkedList.insertFirst(new Employee("12", "Kamali", "b1"));
		linkedList.insertFirst(new Employee("13", "Pradeepa", "c1"));
		linkedList.insertFirst(new Employee("14", "Joe", "d1"));
		linkedList.insertFirst(new Employee("15", "Smith", "e1"));

		linkedList.displayLinkedList();
	}
}
