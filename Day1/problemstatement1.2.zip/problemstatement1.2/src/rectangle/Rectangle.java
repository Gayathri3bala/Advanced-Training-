package rectangle;

public class Rectangle {
	float area;

	public Rectangle(float l, float b) {
		area = l*b;
		System.out.println(" ");
		System.out.println("---------Rectangle Information-----------");
		System.out.println("Length : " + l);
		System.out.println("Width : " + b);
		System.out.println("area of the rectangle is :" + area);
	}
}
