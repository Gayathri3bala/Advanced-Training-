package rectangle;

import java.util.Scanner;

public class TestRectangle {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		float[] l = new float[5];
		float[] b = new float[5];
		System.out.println("Enter the length of 5 Rectangles ");
		Scanner scan = new Scanner(System.in);
		for (int k= 0; k < 5; k++) {
			l[k] = scan.nextFloat();
		}
		System.out.println("Enter the width of 5 Rectangles ");
		for (int k = 0; k < 5; k++) {
			b[k] = scan.nextFloat();
		}
		scan.close();
		Rectangle R1 = new Rectangle(l[0], b[0]);
		Rectangle R2 = new Rectangle(l[1], b[1]);
		Rectangle R3 = new Rectangle(l[2], b[2]);
		Rectangle R4 = new Rectangle(l[3], b[3]);
		Rectangle R5 = new Rectangle(l[4], b[4]);
	}
}
