package aabstractclassandinterface;

class Piano extends Instrument{
	public void Play(){
		System.out.println("Piano is playing tan tan tan tan");
		}
	}
class Flute extends Instrument{
	public void Play(){
		System.out.println("Flute is playing toot toot toot toot");
		}
	}
class Guitar extends Instrument{
	public void Play(){
		System.out.println("Guitar is playing tin tin tin ");
		}
	}
public class Music {
	public static void main(String[] args) 
	{
	Instrument instance[] = new Instrument[10];
	instance[0] = new Piano();
	instance[1] = new Flute();
	instance[2] = new Guitar();
	instance[3] = new Piano();
	instance[4] = new Flute();
	instance[5] = new Guitar();
	instance[6] = new Piano();
	instance[7] = new Flute();
	instance[8] = new Guitar();
	instance[9] = new Piano();
	
	for ( int i = 0 ; i < instance.length ; i++ ){
		if ( instance[i] instanceof Piano ){
			System.out.println("Yes, Its Piano");
			instance[i].Play();
			System.out.println("\n");
			}
			if (instance[i] instanceof Flute) {
				System.out.println("Yes, Its Flute");
				instance[i].Play();
				System.out.println("\n");
			}
			if (instance[i] instanceof Guitar) {
				System.out.println("Yes, Its Guitar");
				instance[i].Play();
				System.out.println("\n");
			}
		}
	}
}



