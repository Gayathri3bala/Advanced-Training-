package com.program.array;

public class Array {
	public static void main(String[] args) {

		int sum = 0, avg, temp;
		int[] array = new int[] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };
		for (int i = 0; i < array.length; i++) {
			sum = sum + array[i];
		}
		System.out.println("Sum of all the elements of an array:" + sum);
		array[15] = sum;
		
		avg = sum / array.length;
		array[16] = avg;
		
		for (int i = 0; i < array.length; i++) {
			System.out.println("  "+array[i]);
		}

		for (int j = 0; j < array.length; j++) {
			for (int k = j + 1; k < array.length; k++) {
				if (array[j] > array[k]) {
					temp = array[j];
					array[j] = array[k];
					array[k] = temp;
				}
			}
		}
		System.out.println("\nSmallest number in the array :" + array[0]);
	}
}
