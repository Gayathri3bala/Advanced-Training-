package com.collectionframework;

import java.util.ArrayList;

public class Students {
	public static void main(String args[]) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("Gayathri");
		list.add("Joe");
		list.add("Smith");
		list.add("Robert");
		list.add("Tom");
		list.add("Julia");
		list.add("Sundar");
		list.add("Ganga");

		System.out.println(list);
		System.out.println(list.size());
		System.out.println(list.get(5));
		System.out.println(list.contains("Julia"));
		for (int i = 0; i <= list.size(); i++) {
			if (list.contains("Smith")) {
			}
		}
		System.out.println("Yes,Smith is in the index of " + list.indexOf("Smith") + " in the list.");
	}
}
