package com.stringmanipulations;

import java.util.regex.Pattern;

public class StringOp {
	public static void main(String args[]) {
		String s = "Java is Simple";
		System.out.println(s.toUpperCase()+"\n");
		System.out.println(s.toLowerCase()+"\n");
		System.out.println("Total length of the string is:" + s.length()+"\n");
		System.out.println(firstLetterWord(s)+"\n");
		System.out.println(reverseWords2(s)+"\n");
		
		String[] s2=s.split(" ");
		for(String a: s2) {
			System.out.println(a);
		}

		StringBuilder str = new StringBuilder(s);
		StringBuilder reverseStr = str.reverse();
		System.out.println("\nReversed String is:" + reverseStr);
	}
	 static String reverseWords2(String s)
	    {
	        Pattern pattern = Pattern.compile("\\s");
	        String[] temp = pattern.split(s);
	        String result = "";
	        for (int i = 0; i < temp.length; i++) {
	            if (i == temp.length - 1)
	                result = temp[i] + result;
	            else
	                result = " " + temp[i] + result;
	        }
	        return result;
	    }
	
	static String firstLetterWord(String s) {
		String result = "";
		boolean v = true;
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == ' ') {
				v = true;
			} else if (s.charAt(i) != ' ' && v == true) {
				result += (s.charAt(i));
				v = false;
			}
		}
		return result;
	}
}
