package com.program.string;

import java.util.Scanner;

public class StringOperations {
	public static void main(String args[]) {
		String string, rev = "";
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string:");
		string = sc.nextLine();

		string = string.toUpperCase();
		System.out.println(string);

		int l = string.length();
		System.out.println("The Length of the String is:" + l);

		for (int i = l - 1; i >= 0; i--)
			rev = rev + string.charAt(i);

		if (string.equals(rev))
			System.out.println("Given String "+ string + " is a palindrome");
		else
			System.out.println("Given String "+ string + " is not a palindrome");
		sc.close();

	}
}
