package com.regularexpression;

public class expressionParser {
public static void main(String[] args) {
		
		
		String txt= (" 23  +  45  -  (  343  /  12  ) ");
		String[] s=txt.split("\s");
		
		for(String str:s){  
			System.out.println(str); 
		}
	}
}
