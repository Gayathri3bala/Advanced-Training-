package com.program.evenno;

import java.util.Scanner;

public class Evennumber {
	public static void main(String args[]) {
		int n;
		System.out.println("Enter the value of n:");
		Scanner s = new Scanner(System.in);
		n = s.nextInt();
		
		for (int i = 0; i < n; i++) {
			if (i % 2 == 0) {
				System.out.println("" + i);
			}
		}
		s.close();
	}
}
