package com.program.multithreading;

public class MainThread implements Runnable{

	public static int count=0;
	
	public void run()
	{
		while(MainThread.count<=5)
		{
			try {
				
				System.out.println("My Thread "+ (++MainThread.count));
				Thread.sleep(1000);
				
			} catch (Exception e) {
				System.out.println("Error Occured "+e);
			}
		}
	}
}
	
	
	

