package com.program.multithreading;

public class sync {
	public static void main(String[] args) {

		int num = 5;
		System.out.println("Factorial of " + num + " is " + factorial(5));
		MainThread ins = new MainThread();
		Thread mythread = new Thread(ins);
		mythread.start();

		while (MainThread.count <= 5) {
			try {

				System.out.println("Main Thread " + (++MainThread.count));
				Thread.sleep(1000);

			} catch (Exception e) {
				System.out.println("Error Occured " + e);
			}
		}

		System.out.println("Main thread completed");
	}

	private static int factorial(int i) {
		if (i == 0) {
			return 1;
		}

		return i * factorial(i - 1);
	}
}
