package com.program.climbingstairs;

import java.util.Scanner;

public class Stairs {
	static int fib(int n) {
		if(n<=1) {
			return n;
		}
		return fib(n-1)+fib(n-2);
	}
	 static int Count(int c) {
		 return fib(c+1);
	 }
	 public static void main(String args[]) {
		 Scanner s=new Scanner(System.in);
		 System.out.println("Enter the no. of stairs:");
		 int c=s.nextInt();
		 System.out.println("\nThe number of ways you can climb to the top : "+Count(c));
	 }
}
