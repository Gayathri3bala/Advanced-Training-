package com.program.repeating;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Decimal {
	public static String decimalProblem(int num,int den) {
		if(num==0) {
			return "0";
		}
		if(den==0) {
			return "Can't divide by 0";
		}
		StringBuilder res=new StringBuilder();
		if((num<0)^(den<0)) {
			res.append("-");
		}
		num=Math.abs(num);
		den=Math.abs(den);
		
		long Q=num/den;
		long R=num%den;
		res.append(String.valueOf(Q));
		
		if(R==0) {
			return res.toString();
		}
		res.append(".");
		Map<Long,Integer> map=new HashMap<>();
		while(R!=0) {
			if(map.containsKey(R)) {
				int i=map.get(R);
				String portion1=res.substring(0, i);
				String portion2="("+res.substring(i, res.length())+")";
				return portion1+portion2;
			}
			map.put(R, res.length());
			Q=R/den;
			res.append(String.valueOf(Q));
			R=(R%den)*10;
		}
		return res.toString();
	}
	
	public static void main(String args[]) {
		
		System.out.println("Enter the values of num and den:");
		Scanner s=new Scanner(System.in);
		int num=s.nextInt();
		Scanner s1=new Scanner(System.in);
		int den=s1.nextInt();
		
		String str=decimalProblem(num,den);
		System.out.println("\n The Repeating decimal of given values is: "+str);
		
	}
}
