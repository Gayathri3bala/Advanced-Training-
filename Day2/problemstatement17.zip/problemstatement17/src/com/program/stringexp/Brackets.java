package com.program.stringexp;

import java.util.ArrayDeque;
import java.util.Deque;

public class Brackets {
	static boolean bracketsBalanced(String exp) {
		Deque<Character> stack = new ArrayDeque<Character>();

		for (int i = 0; i < exp.length(); i++) {
			char a = exp.charAt(i);
			if (a == '(' || a == '[' || a == '{') {
				stack.push(a);
				continue;
			}
			if (stack.isEmpty()) {
				return false;
			}
			char checking;
			switch (a) {
			case ')':
				checking = stack.pop();
				if (checking == '{' || checking == '[') {
					return false;
				}
				break;
			case '}':
				checking = stack.pop();
				if (checking == '(' || checking == '[') {
					return false;
				}
				break;
			case ']':
				checking = stack.pop();
				if (checking == '(' || checking == '{') {
					return false;
				}
				break;
			}
		}
		return (stack.isEmpty());
	}

	public static void main(String args[]) {
		String exp = "[()]{}{[()()]}()";
		if (bracketsBalanced(exp)) {
			System.out.println("Balanced");
		} else {
			System.out.println("Not Balanced");
		}
	}
}
