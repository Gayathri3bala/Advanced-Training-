package problemstatement11;

import java.util.*;

public class Main {
	public static void main(String args[]) {

		System.out.println("Enter the amount for coin change :");
		Scanner s = new Scanner(System.in);
		int v = s.nextInt();
		ArrayList<Integer> list = new ArrayList<Integer>();
		int coins[] = { 1, 2, 5, 10, 20, 50, 100, 500, 2000 };
		int n = coins.length;
		for (int i = n - 1; i >= 0; i--) {
			while (v >= coins[i]) {
				v -= coins[i];
				list.add(coins[i]);
			}
		}
		System.out.println("The minimum no of coins needed for change :\n" + list.size());
		System.out.println("BreakDown-");
		for (int i = 0; i < list.size(); i++) {
			System.out.println(" " + list.get(i));
		}
	}
}
